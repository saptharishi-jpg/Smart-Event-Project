function BookingConfirmationPage({ booking, ticketCode, goTickets, goHome }) {
  return (
    <main className="container">
      <div className="card confirmation">
        <h1>Booking Confirmed</h1>
        <p>Your booking was successful.</p>
        <p>Event: <strong>{booking?.event_title}</strong></p>
        <p>Tickets: {booking?.ticket_quantity}</p>
        <p>Total: ₹{booking?.total_price}</p>
        <p>Ticket Code: <strong>{ticketCode}</strong></p>
        <button onClick={goTickets}>View My Ticket</button>
        <button className="secondary" onClick={goHome}>Back to Events</button>
      </div>
    </main>
  );
}

export default BookingConfirmationPage;
