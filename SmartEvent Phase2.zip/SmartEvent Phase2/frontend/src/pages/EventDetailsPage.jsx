import { useState } from "react";
import api, { authHeaders } from "../api";

function EventDetailsPage({ event, userRole, onBack, onBooked, showMessage, showError }) {
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(false);
  async function book() {
    setLoading(true);
    try {
      const response = await api.post("/bookings", { event_id: event.id, ticket_quantity: quantity }, { headers: authHeaders() });
      onBooked(response.data); showMessage("Booking confirmed successfully.");
    } catch (error) { showError(error.response?.data?.detail || "Booking failed."); }
    finally { setLoading(false); }
  }
  return <main className="container">
    <button className="secondary" onClick={onBack}>← Back</button>
    <div className="details card"><div className="event-box large">{event.category}</div><div>
      <h1>{event.title}</h1><p>{event.description}</p><p><strong>Location:</strong> {event.location}</p>
      <p><strong>Date:</strong> {new Date(event.event_date).toLocaleString()}</p><p><strong>Price:</strong> ₹{event.ticket_price}</p>
      <p><strong>Available:</strong> {event.available_tickets}</p><p><strong>Status:</strong> <span className={`status ${event.event_status?.toLowerCase()}`}>{event.event_status}</span></p>
      {event.event_status === "CANCELLED" ? <div className="cancellation-notice">This event has been cancelled. Ticket sales are closed.</div> : userRole === "USER" ? <>
        <label>Tickets: </label><input className="quantity" type="number" min="1" max={Math.min(10, event.available_tickets)} value={quantity} onChange={e => setQuantity(Number(e.target.value))}/>
        <p><strong>Total: ₹{event.ticket_price * quantity}</strong></p>
        <button onClick={book} disabled={loading || event.available_tickets === 0 || event.event_status !== "UPCOMING"}>{loading ? "Booking..." : "Book Tickets"}</button>
      </> : <p>Sign in with a USER account to book tickets.</p>}
    </div></div>
  </main>;
}
export default EventDetailsPage;
