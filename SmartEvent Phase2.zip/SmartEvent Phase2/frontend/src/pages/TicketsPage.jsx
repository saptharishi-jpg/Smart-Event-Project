import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";
import TicketCard from "../components/TicketCard";

function TicketsPage({ showError, showMessage }) {
  const [tickets, setTickets] = useState([]);
  const apiUrl = import.meta.env.VITE_API_URL || "http://localhost:8000";

  async function loadTickets() {
    try { const response = await api.get("/tickets", { headers: authHeaders() }); setTickets(response.data); }
    catch { showError("Could not load tickets."); }
  }
  useEffect(() => { loadTickets(); }, []);

  async function cancelBooking(ticket) {
    if (!window.confirm(`Cancel the booking for “${ticket.event_title}”? This cancels all ${ticket.ticket_quantity} ticket(s) in that booking.`)) return;
    try {
      await api.post(`/bookings/${ticket.booking_id}/cancel`, {}, { headers: authHeaders() });
      showMessage("Booking cancelled. The tickets are available again.");
      await loadTickets();
    } catch (error) { showError(error.response?.data?.detail || "Could not cancel booking."); }
  }

  return (
    <main className="container">
      <h1>My Tickets</h1>
      {tickets.map((ticket) => <TicketCard key={ticket.id} ticket={ticket} apiUrl={apiUrl} onCancel={() => cancelBooking(ticket)} />)}
      {!tickets.length && <p>No tickets available.</p>}
    </main>
  );
}

export default TicketsPage;
