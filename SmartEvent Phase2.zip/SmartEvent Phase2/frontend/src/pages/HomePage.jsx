import { useEffect, useState } from "react";
import api from "../api";
import EventCard from "../components/EventCard";

function HomePage({ onViewEvent, showError }) {
  const [events, setEvents] = useState([]);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");

  async function loadEvents() {
    try {
      const response = await api.get("/events", { params: { category, search } });
      setEvents(response.data);
    } catch {
      showError("Could not load events.");
    }
  }

  useEffect(() => { loadEvents(); }, [category]);

  return (
    <main className="container">
      <h1>Discover Events</h1>
      <div className="filters">
        <input placeholder="Search by event title" value={search} onChange={(e) => setSearch(e.target.value)} />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option>All</option><option>Music</option><option>Tech</option><option>Sports</option><option>Business</option>
        </select>
        <button onClick={loadEvents}>Search</button>
      </div>
      <div className="event-grid">
        {events.map((event) => <EventCard key={event.id} event={event} onView={onViewEvent} />)}
      </div>
      {!events.length && <p>No events found.</p>}
    </main>
  );
}

export default HomePage;
