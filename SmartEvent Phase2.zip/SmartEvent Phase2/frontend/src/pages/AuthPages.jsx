import { useState } from "react";
import api from "../api";

export function LoginPage({ onLogin, goRegister, showMessage, showError }) {
  const [data, setData] = useState({ email: "", password: "" });

  async function submit(event) {
    event.preventDefault();
    try {
      const response = await api.post("/auth/login", data);
      onLogin(response.data);
      showMessage("Login successful.");
    } catch (error) {
      showError(error.response?.data?.detail || "Login failed.");
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-box" onSubmit={submit}>
        <h1>SmartEvent Login</h1>
        <input type="email" placeholder="Email" value={data.email} onChange={(e) => setData({...data, email: e.target.value})} required />
        <input type="password" placeholder="Password" value={data.password} onChange={(e) => setData({...data, password: e.target.value})} required />
        <button>Login</button>
        <p>Don't have an account?</p>
        <button type="button" className="secondary" onClick={goRegister}>Register</button>
      </form>
    </div>
  );
}

export function RegisterPage({ goLogin, showMessage, showError }) {
  const [data, setData] = useState({ username: "", email: "", password: "" });

  async function submit(event) {
    event.preventDefault();
    try {
      await api.post("/auth/register", data);
      showMessage("Registration successful. Please login.");
      goLogin();
    } catch (error) {
      showError(error.response?.data?.detail || "Registration failed.");
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-box" onSubmit={submit}>
        <h1>Create Account</h1>
        <input placeholder="Username" value={data.username} onChange={(e) => setData({...data, username: e.target.value})} required />
        <input type="email" placeholder="Email" value={data.email} onChange={(e) => setData({...data, email: e.target.value})} required />
        <input type="password" placeholder="Password (minimum 6 characters)" value={data.password} onChange={(e) => setData({...data, password: e.target.value})} required minLength={6} />
        <button>Register</button>
        <p>Already have an account?</p>
        <button type="button" className="secondary" onClick={goLogin}>Login</button>
      </form>
    </div>
  );
}
