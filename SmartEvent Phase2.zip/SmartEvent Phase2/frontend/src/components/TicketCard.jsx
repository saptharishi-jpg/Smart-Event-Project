function TicketCard({ ticket, apiUrl, onCancel }) {
  const qrUrl = `${apiUrl}${ticket.qr_code_url}`;

  return (
    <div className="card ticket-card">
      <div>
        <h3>{ticket.event_title}</h3>
        <p>Ticket Code: <strong>{ticket.ticket_code}</strong></p>
        <p>Date: {new Date(ticket.event_date).toLocaleString()}</p>
        <p>Location: {ticket.location}</p>
        <p>Quantity: {ticket.ticket_quantity}</p>
        {ticket.event_status === "CANCELLED" && <p className="cancellation-notice">This event has been cancelled. This ticket is no longer valid.</p>}
        {ticket.event_status !== "CANCELLED" && <a href={qrUrl} download={`${ticket.ticket_code}.png`} className="button-link">Download QR</a>}
        {ticket.event_status !== "CANCELLED" && new Date(ticket.event_date) > new Date() && <button className="danger cancel-ticket" onClick={onCancel}>Cancel booking</button>}
      </div>
      {ticket.event_status !== "CANCELLED" && <img src={qrUrl} alt="Ticket QR code" className="qr-code" />}
    </div>
  );
}

export default TicketCard;
