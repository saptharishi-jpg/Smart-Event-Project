function NotificationDropdown({ notifications, onRead }) {
  if (!notifications.length) return <p>No notifications.</p>;

  return (
    <div className="notification-list">
      {notifications.map((item) => (
        <div className={`notification ${item.is_read ? "read" : "unread"}`} key={item.id}>
          <strong>{item.title}</strong>
          <p>{item.message}</p>
          {!item.is_read && <button onClick={() => onRead(item.id)}>Mark as read</button>}
        </div>
      ))}
    </div>
  );
}

export default NotificationDropdown;
