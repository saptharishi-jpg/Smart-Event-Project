function EventCard({ event, onView }) {
  return (
    <div className="card">
      <div className="event-box">{event.category}</div>
      <h3>{event.title}</h3>
      <p>{event.location}</p>
      <p>{new Date(event.event_date).toLocaleString()}</p>
      <p><span className={`status ${event.event_status?.toLowerCase()}`}>{event.event_status}</span></p>
      <p><strong>₹{event.ticket_price}</strong></p>
      <p>Tickets left: {event.available_tickets}</p>
      <button onClick={() => onView(event.id)}>View Event</button>
    </div>
  );
}

export default EventCard;
