function ProtectedRoute({ token, children }) {
  if (!token) {
    return <div className="card"><h2>Login required</h2><p>Please login to use this page.</p></div>;
  }
  return children;
}

export default ProtectedRoute;
