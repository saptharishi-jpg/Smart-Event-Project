function Navbar({ user, page, setPage, onLogout, unreadCount }) {
  return (
    <nav className="navbar">
      <button className="logo" onClick={() => setPage("home")}>SmartEvent</button>
      <div className="nav-links">
        <button onClick={() => setPage("home")}>Events</button>
        {user?.role === "USER" && <>
          <button onClick={() => setPage("bookings")}>Bookings</button>
          <button onClick={() => setPage("tickets")}>Tickets</button>
        </>}
        {user?.role === "ORGANIZER" && <button onClick={() => setPage("organizer")}>Organizer dashboard</button>}
        {user?.role === "ADMIN" && <button onClick={() => setPage("admin")}>Admin dashboard</button>}
        <button onClick={() => setPage("notifications")}>Notifications ({unreadCount})</button>
        <span>Hi, {user?.username} <small className="role-label">{user?.role}</small></span>
        <button className="danger" onClick={onLogout}>Logout</button>
      </div>
    </nav>
  );
}

export default Navbar;
