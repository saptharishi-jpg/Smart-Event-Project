from datetime import date, datetime, time, timedelta, timezone
from io import BytesIO
import os, secrets
import bcrypt, qrcode
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text, create_engine, func
from sqlalchemy.orm import Session, declarative_base, sessionmaker, object_session

load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./smartevent.db")
SECRET_KEY = os.getenv("SECRET_KEY", "")
if not SECRET_KEY:
    raise RuntimeError("Set SECRET_KEY in backend/.env before starting SmartEvent")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True); username = Column(String(50), nullable=False); email = Column(String(120), unique=True, nullable=False)
    hashed_password = Column(String, nullable=False); created_at = Column(DateTime, default=datetime.utcnow); role = Column(String(20), nullable=False, default="USER")
class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True); title = Column(String(150), nullable=False); description = Column(Text, nullable=False)
    category = Column(String(30), nullable=False); location = Column(String(150), nullable=False); event_date = Column(DateTime, nullable=False)
    ticket_price = Column(Float, nullable=False); banner_image = Column(String, nullable=True); available_tickets = Column(Integer, default=100)
    created_at = Column(DateTime, default=datetime.utcnow); organizer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    event_status = Column(String(20), nullable=False, default="UPCOMING")
class Booking(Base):
    __tablename__ = "bookings"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"), nullable=False); event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    ticket_quantity = Column(Integer, nullable=False); total_price = Column(Float, nullable=False); booking_status = Column(String(20), default="CONFIRMED"); created_at = Column(DateTime, default=datetime.utcnow)
class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True); booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False); ticket_code = Column(String(50), unique=True, nullable=False)
    qr_code_url = Column(String, nullable=False); created_at = Column(DateTime, default=datetime.utcnow)
class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"), nullable=False); title = Column(String(150), nullable=False)
    message = Column(Text, nullable=False); type = Column(String(20), nullable=False); is_read = Column(Integer, default=0); created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)
def migrate_legacy_db():
    if not DATABASE_URL.startswith("sqlite"): return
    with engine.begin() as conn:
        tables = {r[0] for r in conn.exec_driver_sql("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        for table, fields in {"users": [("role", "VARCHAR(20) NOT NULL DEFAULT 'USER'")], "events": [("organizer_id", "INTEGER REFERENCES users(id)"), ("event_status", "VARCHAR(20) NOT NULL DEFAULT 'UPCOMING'")]}.items():
            if table in tables:
                cols = {r[1] for r in conn.exec_driver_sql(f"PRAGMA table_info({table})").fetchall()}
                for name, declaration in fields:
                    if name not in cols: conn.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {name} {declaration}")
migrate_legacy_db()
def bootstrap_admins():
    emails = [x.strip().lower() for x in os.getenv("ADMIN_EMAILS", "").split(",") if x.strip()]
    if not emails: return
    db = SessionLocal()
    try:
        db.query(User).filter(func.lower(User.email).in_(emails)).update({User.role: "ADMIN"}, synchronize_session=False)
        db.commit()
    finally: db.close()
bootstrap_admins()
app = FastAPI(title="SmartEvent API", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","), allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
security = HTTPBearer(auto_error=False)
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()
def sync_status(event):
    if event.event_status == "CANCELLED": return "CANCELLED"
    now = datetime.utcnow()
    return "UPCOMING" if now < event.event_date else "ONGOING" if now < event.event_date + timedelta(days=1) else "COMPLETED"
def normalize_event_date(value):
    return value.astimezone(timezone.utc).replace(tzinfo=None) if value.tzinfo else value
def token_for(user): return jwt.encode({"user_id": user.id, "role": user.role, "exp": datetime.utcnow()+timedelta(hours=2)}, SECRET_KEY, algorithm="HS256")
def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(security), db: Session = Depends(get_db)):
    if not credentials: raise HTTPException(401, "Authentication required", headers={"WWW-Authenticate":"Bearer"})
    try: payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=["HS256"]); uid, role = payload.get("user_id"), payload.get("role")
    except JWTError: raise HTTPException(401, "Invalid or expired token")
    user = db.query(User).filter(User.id == uid).first()
    if not user or user.role != role: raise HTTPException(401, "Invalid or expired token")
    return user
def require_roles(*roles):
    def guard(user: User = Depends(current_user)):
        if user.role not in roles: raise HTTPException(403, "Insufficient permissions")
        return user
    return guard
def event_dict(e):
    status = sync_status(e)
    if e.event_status != status:
        e.event_status = status
        db = object_session(e)
        if db: db.commit()
    return {"id":e.id,"title":e.title,"description":e.description,"category":e.category,"location":e.location,"event_date":e.event_date.isoformat(),"ticket_price":e.ticket_price,"banner_image":e.banner_image,"available_tickets":e.available_tickets,"organizer_id":e.organizer_id,"event_status":status}
def booking_dict(b,e): return {"id":b.id,"event_id":e.id,"event_title":e.title,"event_date":e.event_date.isoformat(),"event_status":sync_status(e),"location":e.location,"ticket_quantity":b.ticket_quantity,"total_price":b.total_price,"booking_status":b.booking_status,"created_at":b.created_at.isoformat(),"user_id":b.user_id}
def notify_bookers(db,e,title,message):
    for (uid,) in db.query(Booking.user_id).filter(Booking.event_id==e.id,Booking.booking_status=="CONFIRMED").distinct().all(): db.add(Notification(user_id=uid,title=title,message=message,type="EVENT",is_read=0))
class RegisterData(BaseModel): username:str=Field(min_length=2,max_length=50); email:EmailStr; password:str=Field(min_length=6,max_length=100)
class LoginData(BaseModel): email:EmailStr; password:str
class BookingData(BaseModel): event_id:int; ticket_quantity:int=Field(ge=1,le=10)
class EventData(BaseModel):
    title:str=Field(min_length=3,max_length=150); description:str=Field(min_length=5,max_length=5000); category:str=Field(min_length=2,max_length=30)
    location:str=Field(min_length=2,max_length=150); event_date:datetime; ticket_price:float=Field(ge=0); available_tickets:int=Field(ge=1,le=1000000); banner_image:str|None=Field(default=None,max_length=1000)
class RoleUpdate(BaseModel): role:str

@app.get("/")
def home(): return {"message":"SmartEvent API is running","version":"2.0.0"}
@app.post("/auth/register")
def register(data:RegisterData,db:Session=Depends(get_db)):
    if db.query(User).filter(User.email==data.email).first(): raise HTTPException(400,"Email already registered")
    admins={x.strip().lower() for x in os.getenv("ADMIN_EMAILS","").split(",") if x.strip()}
    user=User(username=data.username,email=data.email,hashed_password=bcrypt.hashpw(data.password.encode(),bcrypt.gensalt()).decode(),role="ADMIN" if data.email.lower() in admins else "USER")
    db.add(user);db.commit();return {"message":"Registration successful"}
@app.post("/auth/login")
def login(data:LoginData,db:Session=Depends(get_db)):
    u=db.query(User).filter(User.email==data.email).first()
    if not u or not bcrypt.checkpw(data.password.encode(),u.hashed_password.encode()): raise HTTPException(401,"Invalid email or password")
    return {"access_token":token_for(u),"token_type":"bearer","user":{"id":u.id,"username":u.username,"email":u.email,"role":u.role}}
@app.get("/auth/profile")
def profile(user:User=Depends(current_user)): return {"id":user.id,"username":user.username,"email":user.email,"role":user.role,"created_at":user.created_at.isoformat()}
@app.get("/events")
def events(category:str|None=None,search:str|None=None,db:Session=Depends(get_db)):
    q=db.query(Event).filter(Event.event_status!="CANCELLED")
    if category and category!="All": q=q.filter(Event.category==category)
    if search: q=q.filter(Event.title.ilike(f"%{search}%"))
    return [event_dict(e) for e in q.order_by(Event.event_date).all()]
@app.get("/events/categories/list")
def categories(): return ["All","Music","Tech","Sports","Business"]
@app.get("/events/{event_id}")
def get_event(event_id:int,db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e: raise HTTPException(404,"Event not found")
    return event_dict(e)
@app.post("/events")
def create_event(data:EventData,user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    values=data.model_dump();values["event_date"]=normalize_event_date(values["event_date"])
    e=Event(**values,organizer_id=user.id,event_status="UPCOMING");db.add(e);db.commit();db.refresh(e);return event_dict(e)
@app.get("/organizer/events")
def my_events(user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    q=db.query(Event)
    if user.role!="ADMIN": q=q.filter(Event.organizer_id==user.id)
    return [event_dict(e) for e in q.order_by(Event.event_date.desc()).all()]
@app.put("/events/{event_id}")
def update_event(event_id:int,data:EventData,user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e: raise HTTPException(404,"Event not found")
    if user.role!="ADMIN" and e.organizer_id!=user.id: raise HTTPException(403,"You can only manage your own events")
    if e.event_status=="CANCELLED": raise HTTPException(400,"Cancelled events cannot be edited")
    values=data.model_dump();values["event_date"]=normalize_event_date(values["event_date"])
    for k,v in values.items(): setattr(e,k,v)
    e.event_status=sync_status(e);notify_bookers(db,e,"Event updated",f"{e.title} has been updated. Review the latest details.");db.commit();return event_dict(e)
@app.post("/events/{event_id}/cancel")
def cancel_event(event_id:int,user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e: raise HTTPException(404,"Event not found")
    if user.role!="ADMIN" and e.organizer_id!=user.id: raise HTTPException(403,"You can only manage your own events")
    if e.event_status!="CANCELLED": e.event_status="CANCELLED";notify_bookers(db,e,"Event cancelled",f"{e.title} has been cancelled. Contact support about refunds.");db.commit()
    return event_dict(e)
def booking_rows(user,db,event_id=None):
    q=db.query(Booking,Event,User).join(Event,Booking.event_id==Event.id).join(User,Booking.user_id==User.id)
    if user.role!="ADMIN":q=q.filter(Event.organizer_id==user.id)
    if event_id is not None:q=q.filter(Event.id==event_id)
    return [{**booking_dict(b,e),"username":u.username,"email":u.email} for b,e,u in q.order_by(Booking.created_at.desc()).all()]
@app.get("/organizer/bookings")
def organizer_bookings(user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):return booking_rows(user,db)
@app.get("/organizer/events/{event_id}/bookings")
def event_bookings(event_id:int,user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e:raise HTTPException(404,"Event not found")
    if user.role!="ADMIN" and e.organizer_id!=user.id:raise HTTPException(403,"You can only view bookings for your own events")
    return booking_rows(user,db,event_id)
@app.get("/organizer/analytics")
def organizer_analytics(user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    q=db.query(Event)
    if user.role!="ADMIN":q=q.filter(Event.organizer_id==user.id)
    result=[]
    for e in q.all():
        sold,revenue,count=db.query(func.coalesce(func.sum(Booking.ticket_quantity),0),func.coalesce(func.sum(Booking.total_price),0),func.count(Booking.id)).filter(Booking.event_id==e.id,Booking.booking_status=="CONFIRMED").one()
        result.append({"event_id":e.id,"event_title":e.title,"tickets_sold":int(sold),"remaining_tickets":e.available_tickets,"revenue":float(revenue),"booking_count":int(count)})
    return {"events":result,"totals":{"tickets_sold":sum(x["tickets_sold"] for x in result),"remaining_tickets":sum(x["remaining_tickets"] for x in result),"revenue":sum(x["revenue"] for x in result),"booking_count":sum(x["booking_count"] for x in result)}}
@app.get("/admin/users")
def admin_users(user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):
    return [{"id":u.id,"username":u.username,"email":u.email,"role":u.role,"created_at":u.created_at.isoformat()} for u in db.query(User).order_by(User.created_at.desc()).all()]
@app.patch("/admin/users/{user_id}/role")
def set_role(user_id:int,data:RoleUpdate,user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):
    role=data.role.upper()
    if role not in ("USER","ORGANIZER","ADMIN"):raise HTTPException(422,"Role must be USER, ORGANIZER, or ADMIN")
    target=db.query(User).filter(User.id==user_id).first()
    if not target:raise HTTPException(404,"User not found")
    target.role=role;db.commit();return {"id":target.id,"role":target.role}
@app.get("/admin/events")
def admin_events(user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):return [event_dict(e) for e in db.query(Event).order_by(Event.event_date.desc()).all()]
@app.get("/admin/bookings")
def admin_bookings(user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):return booking_rows(user,db)
@app.get("/admin/analytics")
def admin_analytics(start_date:date|None=None,end_date:date|None=None,user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):
    q=db.query(Booking,Event).join(Event,Booking.event_id==Event.id).filter(Booking.booking_status=="CONFIRMED")
    if start_date:q=q.filter(Booking.created_at>=datetime.combine(start_date,time.min))
    if end_date:q=q.filter(Booking.created_at<datetime.combine(end_date+timedelta(days=1),time.min))
    rows=q.all();daily={};monthly={};popular={};top={}
    for b,e in rows:
        d=b.created_at.date().isoformat();m=b.created_at.strftime("%Y-%m");daily[d]=daily.get(d,0)+b.ticket_quantity;monthly[m]=monthly.get(m,0)+1;popular[e.title]=popular.get(e.title,0)+b.ticket_quantity;top[e.title]=top.get(e.title,0)+b.total_price
    return {"total_users":db.query(func.count(User.id)).scalar() or 0,"total_events":db.query(func.count(Event.id)).scalar() or 0,"total_bookings":len(rows),"total_tickets_sold":sum(b.ticket_quantity for b,e in rows),"total_revenue":sum(b.total_price for b,e in rows),"daily_ticket_sales":[{"date":k,"tickets":v} for k,v in sorted(daily.items())],"monthly_booking_trends":[{"month":k,"bookings":v} for k,v in sorted(monthly.items())],"popular_events":[{"event":k,"tickets":v} for k,v in sorted(popular.items(),key=lambda x:x[1],reverse=True)[:10]],"top_revenue_events":[{"event":k,"revenue":v} for k,v in sorted(top.items(),key=lambda x:x[1],reverse=True)[:10]]}
@app.post("/bookings")
def create_booking(data:BookingData,user:User=Depends(require_roles("USER")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==data.event_id).first()
    if not e:raise HTTPException(404,"Event not found")
    e.event_status=sync_status(e)
    if e.event_status in ("CANCELLED","COMPLETED"):raise HTTPException(400,"This event is not accepting bookings")
    if data.ticket_quantity>e.available_tickets:raise HTTPException(400,"Tickets are sold out or unavailable")
    b=Booking(user_id=user.id,event_id=e.id,ticket_quantity=data.ticket_quantity,total_price=e.ticket_price*data.ticket_quantity,booking_status="CONFIRMED");e.available_tickets-=data.ticket_quantity;db.add(b);db.commit();db.refresh(b)
    code="TKT-"+secrets.token_hex(6).upper();t=Ticket(booking_id=b.id,ticket_code=code,qr_code_url=f"/tickets/{code}/qr");db.add(t);db.add(Notification(user_id=user.id,title="Booking confirmed",message=f"Your booking for {e.title} is confirmed.",type="BOOKING",is_read=0));db.commit()
    return {"message":"Booking confirmed","booking":booking_dict(b,e),"ticket_code":code}
@app.get("/bookings")
def my_bookings(user:User=Depends(current_user),db:Session=Depends(get_db)):
    return [booking_dict(b,e) for b,e in db.query(Booking,Event).join(Event,Booking.event_id==Event.id).filter(Booking.user_id==user.id).order_by(Booking.created_at.desc()).all()]
@app.post("/bookings/{booking_id}/cancel")
def cancel_booking(booking_id:int,user:User=Depends(require_roles("USER","ADMIN")),db:Session=Depends(get_db)):
    query=db.query(Booking).filter(Booking.id==booking_id)
    if user.role!="ADMIN": query=query.filter(Booking.user_id==user.id)
    booking=query.first()
    if not booking: raise HTTPException(404,"Booking not found")
    if booking.booking_status!="CONFIRMED": raise HTTPException(400,"This booking is already cancelled")
    event=db.query(Event).filter(Event.id==booking.event_id).first()
    if not event: raise HTTPException(404,"Event not found")
    if event.event_date<=datetime.utcnow(): raise HTTPException(400,"Bookings can only be cancelled before the event starts")
    booking.booking_status="CANCELLED"
    event.available_tickets+=booking.ticket_quantity
    message=f"Your booking for {event.title} has been cancelled." if user.role!="ADMIN" else f"An administrator cancelled your booking for {event.title}."
    db.add(Notification(user_id=booking.user_id,title="Booking cancelled",message=message,type="BOOKING",is_read=0))
    db.commit()
    return {"message":"Booking cancelled","booking_id":booking.id,"available_tickets":event.available_tickets}
@app.get("/tickets")
def tickets(user:User=Depends(current_user),db:Session=Depends(get_db)):
    return [{"id":t.id,"booking_id":b.id,"ticket_code":t.ticket_code,"qr_code_url":t.qr_code_url,"event_title":e.title,"event_date":e.event_date.isoformat(),"event_status":sync_status(e),"location":e.location,"ticket_quantity":b.ticket_quantity} for t,b,e in db.query(Ticket,Booking,Event).join(Booking,Ticket.booking_id==Booking.id).join(Event,Booking.event_id==Event.id).filter(Booking.user_id==user.id,Booking.booking_status=="CONFIRMED").all()]
@app.get("/tickets/{ticket_code}/qr")
def qr(ticket_code:str,db:Session=Depends(get_db)):
    ticket=db.query(Ticket).filter(Ticket.ticket_code==ticket_code).first()
    booking=db.query(Booking).filter(Booking.id==ticket.booking_id,Booking.booking_status=="CONFIRMED").first() if ticket else None
    event=db.query(Event).filter(Event.id==booking.event_id).first() if booking else None
    if not ticket or not booking or not event or event.event_status=="CANCELLED":raise HTTPException(404,"Ticket not found")
    img=BytesIO();qrcode.make(ticket_code).save(img,format="PNG");img.seek(0);return StreamingResponse(img,media_type="image/png")
@app.get("/tickets/verify/{ticket_code}")
def verify(ticket_code:str,db:Session=Depends(get_db)):
    ticket=db.query(Ticket).filter(Ticket.ticket_code==ticket_code).first()
    booking=db.query(Booking).filter(Booking.id==ticket.booking_id,Booking.booking_status=="CONFIRMED").first() if ticket else None
    event=db.query(Event).filter(Event.id==booking.event_id).first() if booking else None
    if not ticket or not booking or not event or event.event_status=="CANCELLED":raise HTTPException(404,"Invalid ticket")
    return {"valid":True,"ticket_code":ticket_code}
@app.get("/notifications")
def notifications(user:User=Depends(current_user),db:Session=Depends(get_db)):
    return [{"id":n.id,"title":n.title,"message":n.message,"type":n.type,"is_read":bool(n.is_read),"created_at":n.created_at.isoformat()} for n in db.query(Notification).filter(Notification.user_id==user.id).order_by(Notification.created_at.desc()).all()]
@app.patch("/notifications/{notification_id}/read")
def read_notification(notification_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    n=db.query(Notification).filter(Notification.id==notification_id,Notification.user_id==user.id).first()
    if not n:raise HTTPException(404,"Notification not found")
    n.is_read=1;db.commit();return {"message":"Notification marked as read"}
